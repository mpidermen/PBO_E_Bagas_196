// Superclass KarakterGame sebagai dasar untuk semua karakter dalam game
class KarakterGame
{
    // Atribut nama dan kesehatan yang dimiliki setiap karakter
    private String nama;
    private int kesehatan;

    // Constructor untuk menginisialisasi nama dan kesehatan karakter
    public KarakterGame(String nama, int kesehatan)
    {
        this.nama = nama;
        this.kesehatan = kesehatan;
    }

    // Getter untuk mendapatkan nama karakter
    public String getNama()
    {
        return nama;
    }

    // Setter untuk mengubah nama karakter
    public void setNama(String nama)
    {
        this.nama = nama;
    }

    // Getter untuk mendapatkan nilai kesehatan karakter
    public int getKesehatan()
    {
        return kesehatan;
    }

    // Setter untuk mengubah nilai kesehatan karakter
    public void setKesehatan(int kesehatan)
    {
        this.kesehatan = kesehatan;
    }

    // Method serang yang akan dioverride oleh subclass
    public void serang(KarakterGame target)
    {
        System.out.println(this.nama + " menyerang " + target.getNama());
    }
}

// Subclass Pahlawan yang mewarisi dari KarakterGame
class Pahlawan extends KarakterGame
{
    // Constructor untuk menginisialisasi nama dan kesehatan pahlawan
    public Pahlawan(String nama, int kesehatan)
    {
        super(nama, kesehatan);
    }

    // Override method serang untuk pahlawan
    @Override
    public void serang(KarakterGame target)
    {
        System.out.println(getNama() + " menyerang " + target.getNama() + " menggunakan pedang!");
        // Mengurangi kesehatan target sebesar 20 poin
        target.setKesehatan(target.getKesehatan() - 20);
        System.out.println(target.getNama() + " sekarang memiliki kesehatan " + target.getKesehatan());
    }
}

// Subclass Musuh yang mewarisi dari KarakterGame
class Musuh extends KarakterGame
{
    // Constructor untuk menginisialisasi nama dan kesehatan musuh
    public Musuh(String nama, int kesehatan)
    {
        super(nama, kesehatan);
    }

    // Override method serang untuk musuh
    @Override
    public void serang(KarakterGame target)
    {
        System.out.println(getNama() + " menyerang " + target.getNama() + " menggunakan sihir!");
        // Mengurangi kesehatan target sebesar 15 poin
        target.setKesehatan(target.getKesehatan() - 15);
        System.out.println(target.getNama() + " sekarang memiliki kesehatan " + target.getKesehatan());
    }
}

// Kelas utama untuk menjalankan program
public class Main
{
    public static void main(String[] args)
    {
        // Membuat objek karakter umum (tidak digunakan dalam pertarungan)
        KarakterGame karakterUmum = new KarakterGame("Karakter Umum", 100);

        // Membuat objek pahlawan dengan nama "Brimstone" dan kesehatan awal 150
        Pahlawan brimstone = new Pahlawan("Brimstone", 150);

        // Membuat objek musuh dengan nama "Viper" dan kesehatan awal 200
        Musuh viper = new Musuh("Viper", 200);

        // Menampilkan status awal karakter
        System.out.println("Status awal:");
        System.out.println(brimstone.getNama() + " memiliki kesehatan: " + brimstone.getKesehatan());
        System.out.println(viper.getNama() + " memiliki kesehatan: " + viper.getKesehatan());

        // Simulasi serangan antar karakter
        brimstone.serang(viper);  // Pahlawan menyerang musuh
        viper.serang(brimstone);  // Musuh menyerang pahlawan
    }
}
